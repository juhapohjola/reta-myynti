import { useState, useRef, useEffect } from "react";

// ── SUPABASE CONFIG ───────────────────────────────────────────────────────────
const SUPABASE_URL = "https://yjfoiojbtwrktowlgryp.supabase.co";
const SUPABASE_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InlqZm9pb2pidHdya3Rvd2xncnlwIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzYyOTMwNzcsImV4cCI6MjA5MTg2OTA3N30.naOVBIufqGFBm3SXzqP4ydT9SQwNismavkhb4Iaupq4";
const SB = (path, opts = {}) => fetch(`${SUPABASE_URL}/rest/v1/${path}`, {
  headers: { apikey: SUPABASE_KEY, Authorization: `Bearer ${SUPABASE_KEY}`, "Content-Type": "application/json", Prefer: "return=representation", ...opts.headers },
  ...opts
}).then(r => r.json());

// DB helpers
const db = {
  getItems: () => SB("items?order=created_at.desc,id.desc&select=*"),
  addItem: (item) => SB("items", { method: "POST", body: JSON.stringify(toDb(item)) }),
  updateItem: (id, item) => SB(`items?id=eq.${id}`, { method: "PATCH", body: JSON.stringify(toDb(item)) }),
  saveInvoice: (inv) => SB("invoices", { method: "POST", body: JSON.stringify(inv) }),
};

function toDb(item) {
  return {
    name: item.name,
    category: item.category,
    condition: item.condition,
    description: item.description || null,
    buy_price: item.buyPrice ? Number(item.buyPrice) : null,
    sell_price: item.sellPrice ? Number(item.sellPrice) : null,
    sold: item.sold || false,
    sold_at: item.soldAt || null,
    added_by: item.addedBy || null,
    sold_by: item.soldBy || null,
    created_at: item.createdAt || new Date().toISOString().split("T")[0],
    image_data: item.imageData || [],
  };
}

function fromDb(row) {
  return {
    id: row.id,
    name: row.name,
    category: row.category,
    condition: row.condition,
    description: row.description,
    buyPrice: row.buy_price,
    sellPrice: row.sell_price,
    sold: row.sold,
    soldAt: row.sold_at,
    addedBy: row.added_by,
    soldBy: row.sold_by,
    createdAt: row.created_at,
    imageData: row.image_data || [],
  };
}

const C = {
  navy: "#1e3a6e", navyDark: "#152d57", navyLight: "#2a4f8f",
  blue: "#4a90d9", blueLight: "#6aaee8",
  white: "#ffffff", offWhite: "#f0f4f9", bg: "#e8eef6",
  border: "#c8d8ec", borderLight: "#dce8f4",
  textMuted: "#5a7aa8", textLight: "#8aaad0",
  green: "#1e8c4a", greenBg: "#e6f4ec",
  amber: "#d97706", amberBg: "#fef3e2",
  red: "#dc2626", redBg: "#fee2e2",
  lime: "#65a30d",
  gold: "#b8860b", goldBg: "#fdf6e3",
};

// Käyttäjät — lisää tähän uusia työntekijöitä
const USERS = [
  { id: "admin", name: "Matti Pohjola", pin: "1234", role: "admin", avatar: "👔" },
  { id: "user1", name: "Jooa", pin: "1111", role: "user", avatar: "👤" },
  { id: "user2", name: "Okko", pin: "2222", role: "user", avatar: "👤" },
  { id: "user3", name: "Kaius", pin: "3333", role: "user", avatar: "👤" },
  { id: "user4", name: "Paulus", pin: "4444", role: "user", avatar: "👤" },
  { id: "user5", name: "Nico", pin: "5555", role: "user", avatar: "👤" },
  { id: "user6", name: "Michael", pin: "6666", role: "user", avatar: "👤" },
];

const CATEGORIES = [
  { id: "uunit", label: "Uunit & Paistot", icon: "🔥" },
  { id: "pesukoneet", label: "Pesukoneet", icon: "🫧" },
  { id: "kylmalaitteet", label: "Kylmälaitteet", icon: "❄️" },
  { id: "poydät", label: "Pöydät & Tasot", icon: "📋" },
  { id: "taikinakoneet", label: "Taikinakoneet", icon: "🌾" },
  { id: "kahvikoneet", label: "Kahvikoneet", icon: "☕" },
  { id: "leikkurit", label: "Leikkurit & Viipalointikoneet", icon: "🔪" },
  { id: "keittiot", label: "Keittiökoneet & Sekoittimet", icon: "🥣" },
  { id: "friteerit", label: "Friteerit & Grillit", icon: "🍳" },
  { id: "hyllyt", label: "Hyllyt & Säilytys", icon: "🗄️" },
  { id: "huuvat", label: "Huuvat & Ilmanvaihto", icon: "💨" },
  { id: "muut", label: "Muut laitteet", icon: "⚙️" },
];

const CONDITION_LABELS = {
  erinomainen: { label: "Erinomainen", color: C.green, bg: C.greenBg },
  hyva: { label: "Hyvä", color: C.lime, bg: "#f0f9e6" },
  tyydyttava: { label: "Tyydyttävä", color: C.amber, bg: C.amberBg },
  korjausta: { label: "Vaatii korjausta", color: C.red, bg: C.redBg },
};

// Data tulee Supabasesta
function formatEur(val) {
  if (val === null || val === undefined || val === "") return "—";
  return Number(val).toLocaleString("fi-FI", { style: "currency", currency: "EUR", maximumFractionDigits: 0 });
}
function userName(id) {
  return USERS.find(u => u.id === id)?.name || "—";
}

// ── LOGO ──────────────────────────────────────────────────────────────────────
function RetaLogo({ small }) {
  const sz = small ? 20 : 27;
  return (
    <div style={{ fontFamily: "'Barlow Condensed', sans-serif", fontWeight: 800, lineHeight: 1.0, userSelect: "none" }}>
      <div style={{ fontSize: sz, color: C.navy, letterSpacing: "1px", display: "flex", alignItems: "center", gap: "5px" }}>
        RETA
        <svg width={small?9:12} height={small?11:14} viewBox="0 0 12 14"><polygon points="0,0 12,7 0,14" fill={C.blue} /></svg>
      </div>
      <div style={{ fontSize: sz, color: C.navy, letterSpacing: "1px", marginTop: "-3px" }}>MYYNTI</div>
    </div>
  );
}

// ── LOGIN SCREEN ──────────────────────────────────────────────────────────────
function LoginScreen({ onLogin }) {
  const [selected, setSelected] = useState(null);
  const [pin, setPin] = useState("");
  const [error, setError] = useState("");

  function handlePin(digit) {
    if (pin.length >= 4) return;
    const next = pin + digit;
    setPin(next);
    setError("");
    if (next.length === 4) {
      const user = USERS.find(u => u.id === selected && u.pin === next);
      if (user) { onLogin(user); }
      else { setError("Väärä PIN-koodi"); setTimeout(() => setPin(""), 600); }
    }
  }

  return (
    <div style={{ minHeight: "100vh", background: C.navy, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", padding: "24px", overflowX: "hidden", maxWidth: "100vw" }}>
      <link href="https://fonts.googleapis.com/css2?family=Barlow+Condensed:wght@400;600;700;800&family=Barlow:wght@300;400;500;600&display=swap" rel="stylesheet" />
      <style>{`html,body{overflow-x:hidden;overscroll-behavior-x:none;touch-action:pan-y;max-width:100vw}`}</style>
      <div style={{ marginBottom: "32px" }}>
        <div style={{ fontFamily: "'Barlow Condensed', sans-serif", fontWeight: 800, lineHeight: 1.0, textAlign: "center" }}>
          <div style={{ fontSize: "42px", color: C.white, letterSpacing: "2px", display: "flex", alignItems: "center", justifyContent: "center", gap: "8px" }}>
            RETA
            <svg width="18" height="22" viewBox="0 0 12 14"><polygon points="0,0 12,7 0,14" fill={C.blue} /></svg>
          </div>
          <div style={{ fontSize: "42px", color: C.white, letterSpacing: "2px", marginTop: "-6px" }}>MYYNTI</div>
        </div>
        <div style={{ color: C.blueLight, fontSize: "11px", letterSpacing: "3px", textAlign: "center", marginTop: "6px" }}>KÄYTETYT SUURKEITTIÖLAITTEET</div>
      </div>

      <div style={{ background: "rgba(255,255,255,0.08)", borderRadius: "16px", padding: "28px", width: "100%", maxWidth: "380px" }}>
        {!selected ? (
          <>
            <div style={{ color: C.blueLight, fontSize: "11px", letterSpacing: "2px", marginBottom: "16px", fontWeight: 700, fontFamily: "'Barlow Condensed', sans-serif" }}>VALITSE KÄYTTÄJÄ</div>
            <div style={{ display: "flex", flexDirection: "column", gap: "8px" }}>
              {USERS.map(u => (
                <button key={u.id} onClick={() => { setSelected(u.id); setPin(""); setError(""); }} style={{
                  display: "flex", alignItems: "center", gap: "14px",
                  background: "rgba(255,255,255,0.06)", border: "1px solid rgba(255,255,255,0.12)",
                  borderRadius: "10px", padding: "14px 16px", cursor: "pointer", color: C.white,
                  fontFamily: "'Barlow', sans-serif", fontSize: "15px", fontWeight: 500, textAlign: "left"
                }}>
                  <span style={{ fontSize: "22px" }}>{u.avatar}</span>
                  <div>
                    <div style={{ color: C.white, fontWeight: 600 }}>{u.name}</div>
                    <div style={{ color: C.blueLight, fontSize: "11px", marginTop: "1px" }}>{u.role === "admin" ? "Hallinta" : "Myyjä"}</div>
                  </div>
                </button>
              ))}
            </div>
          </>
        ) : (
          <>
            <button onClick={() => { setSelected(null); setPin(""); }} style={{ background: "none", border: "none", color: C.blueLight, cursor: "pointer", fontSize: "13px", marginBottom: "16px", padding: 0 }}>← Vaihda käyttäjä</button>
            <div style={{ textAlign: "center", marginBottom: "20px" }}>
              <div style={{ fontSize: "28px", marginBottom: "6px" }}>{USERS.find(u => u.id === selected)?.avatar}</div>
              <div style={{ color: C.white, fontWeight: 700, fontSize: "16px" }}>{USERS.find(u => u.id === selected)?.name}</div>
              <div style={{ color: C.blueLight, fontSize: "12px", marginTop: "4px" }}>Anna PIN-koodi</div>
            </div>
            {/* PIN dots */}
            <div style={{ display: "flex", justifyContent: "center", gap: "14px", marginBottom: "24px" }}>
              {[0,1,2,3].map(i => (
                <div key={i} style={{ width: "14px", height: "14px", borderRadius: "50%", background: i < pin.length ? C.blue : "rgba(255,255,255,0.2)", transition: "background 0.15s" }} />
              ))}
            </div>
            {error && <div style={{ color: "#ff8a8a", fontSize: "13px", textAlign: "center", marginBottom: "12px" }}>{error}</div>}
            {/* Numpad */}
            <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: "10px" }}>
              {[1,2,3,4,5,6,7,8,9,"",0,"⌫"].map((d, i) => (
                <button key={i} onClick={() => { if (d === "⌫") { setPin(p => p.slice(0,-1)); setError(""); } else if (d !== "") handlePin(String(d)); }}
                  disabled={d === ""}
                  style={{ background: d === "" ? "transparent" : "rgba(255,255,255,0.1)", border: d === "" ? "none" : "1px solid rgba(255,255,255,0.15)", borderRadius: "10px", padding: "16px", color: C.white, fontSize: d === "⌫" ? "18px" : "20px", fontWeight: 600, cursor: d === "" ? "default" : "pointer", fontFamily: "'Barlow Condensed', sans-serif" }}>
                  {d}
                </button>
              ))}
            </div>
          </>
        )}
      </div>
    </div>
  );
}

// ── PRICE SEARCH MODAL ────────────────────────────────────────────────────────
function PriceSearchModal({ item, onClose }) {
  const q = encodeURIComponent(item.name);
  const links = [
    { icon: "🔍", name: "Google", desc: "käytetty + hinta", url: `https://www.google.com/search?q=${encodeURIComponent("käytetty " + item.name + " myyntihinta")}` },
    { icon: "🔨", name: "Huuto.net", desc: "suomalainen huutokauppa", url: `https://www.huuto.net/haku?words=${q}` },
    { icon: "📦", name: "Tori.fi", desc: "suomalainen myyntipalvelu", url: `https://www.tori.fi/koko_suomi?q=${q}` },
    { icon: "🌐", name: "eBay", desc: "kansainvälinen hintavertailu", url: `https://www.ebay.com/sch/i.html?_nkw=${encodeURIComponent("used " + item.name)}` },
    { icon: "🏭", name: "Machineseeker", desc: "käytetyt teollisuuslaitteet", url: `https://www.machineseeker.fi/?s=${q}` },
  ];
  return (
    <div style={{ position: "fixed", inset: 0, background: "rgba(15,30,60,0.65)", zIndex: 1000, display: "flex", alignItems: "center", justifyContent: "center", padding: "20px" }}>
      <div style={{ background: C.white, borderRadius: "16px", width: "100%", maxWidth: "500px", padding: "20px 16px", boxShadow: "0 24px 64px rgba(30,58,110,0.25)" }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: "8px" }}>
          <div>
            <div style={{ color: C.blue, fontFamily: "'Barlow Condensed', sans-serif", fontSize: "11px", letterSpacing: "3px", fontWeight: 700, marginBottom: "6px" }}>HINTAHAKU</div>
            <div style={{ color: C.navy, fontSize: "16px", fontWeight: 700, fontFamily: "'Barlow Condensed', sans-serif" }}>{item.name}</div>
          </div>
          <button onClick={onClose} style={{ background: C.offWhite, border: "none", color: C.textMuted, fontSize: "20px", cursor: "pointer", borderRadius: "8px", width: "36px", height: "36px" }}>×</button>
        </div>
        <p style={{ color: C.textMuted, fontSize: "13px", marginBottom: "16px", lineHeight: 1.5 }}>Avaa palvelu ja vertaa vastaavien laitteiden hintoja.</p>
        <div style={{ display: "flex", flexDirection: "column", gap: "8px" }}>
          {links.map((s, i) => (
            <a key={i} href={s.url} target="_blank" rel="noopener noreferrer" style={{ display: "flex", alignItems: "center", gap: "14px", background: i === 0 ? `linear-gradient(135deg, ${C.navy}, ${C.navyLight})` : C.offWhite, color: i === 0 ? C.white : C.navy, border: `1px solid ${i === 0 ? C.navy : C.border}`, borderRadius: "10px", padding: "12px 16px", textDecoration: "none" }}>
              <span style={{ fontSize: "18px", width: "26px", textAlign: "center" }}>{s.icon}</span>
              <div style={{ flex: 1 }}>
                <div style={{ fontWeight: 700, fontSize: "14px" }}>{s.name}</div>
                <div style={{ fontSize: "11px", opacity: 0.6 }}>{s.desc}</div>
              </div>
              <span style={{ opacity: 0.4 }}>↗</span>
            </a>
          ))}
        </div>
      </div>
    </div>
  );
}

// ── ITEM MODAL ────────────────────────────────────────────────────────────────
function ItemModal({ item, onClose, onSave, currentUser }) {
  const [form, setForm] = useState(item || { name: "", category: "uunit", condition: "hyva", description: "", buyPrice: "", sellPrice: "", sold: false, imageData: [], soldAt: "", addedBy: currentUser.id, soldBy: null });
  const [previewImages, setPreviewImages] = useState(item?.imageData || []);
  const fileRef = useRef();

  function handleImageUpload(e) {
    Array.from(e.target.files).forEach(file => {
      const reader = new FileReader();
      reader.onload = ev => setPreviewImages(prev => [...prev, { src: ev.target.result, name: file.name }]);
      reader.readAsDataURL(file);
    });
  }

  const inp = { background: C.offWhite, border: `1.5px solid ${C.border}`, borderRadius: "8px", color: C.navy, padding: "10px 14px", fontSize: "14px", width: "100%", boxSizing: "border-box", fontFamily: "'Barlow', sans-serif", outline: "none" };
  const lbl = { color: C.textMuted, fontSize: "11px", letterSpacing: "2px", marginBottom: "6px", display: "block", fontWeight: 700, fontFamily: "'Barlow Condensed', sans-serif" };

  return (
    <div style={{ position: "fixed", inset: 0, background: "rgba(15,30,60,0.65)", zIndex: 1000, display: "flex", alignItems: "center", justifyContent: "center", padding: "20px" }}>
      <div style={{ background: C.white, borderRadius: "16px", width: "100%", maxWidth: "680px", padding: "36px", maxHeight: "92vh", overflowY: "auto", boxShadow: "0 24px 64px rgba(30,58,110,0.25)" }}>
        <div style={{ display: "flex", justifyContent: "space-between", marginBottom: "28px", alignItems: "center" }}>
          <div style={{ fontFamily: "'Barlow Condensed', sans-serif", color: C.navy, fontSize: "22px", fontWeight: 800 }}>
            {item ? "MUOKKAA LAITETTA" : "LISÄÄ UUSI LAITE"}
          </div>
          <button onClick={onClose} style={{ background: C.offWhite, border: "none", color: C.textMuted, fontSize: "20px", cursor: "pointer", borderRadius: "8px", width: "36px", height: "36px" }}>×</button>
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(240px, 1fr))", gap: "12px" }}>
          <div style={{ gridColumn: "1/-1" }}>
            <label style={lbl}>LAITTEEN NIMI *</label>
            <input style={inp} value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} placeholder="esim. Rational SelfCooking Center 6-taso" />
          </div>
          <div>
            <label style={lbl}>KATEGORIA</label>
            <select style={inp} value={form.category} onChange={e => setForm(f => ({ ...f, category: e.target.value }))}>
              {CATEGORIES.map(c => <option key={c.id} value={c.id}>{c.icon} {c.label}</option>)}
            </select>
          </div>
          <div>
            <label style={lbl}>KUNTO</label>
            <select style={inp} value={form.condition} onChange={e => setForm(f => ({ ...f, condition: e.target.value }))}>
              {Object.entries(CONDITION_LABELS).map(([k, v]) => <option key={k} value={k}>{v.label}</option>)}
            </select>
          </div>
          <div>
            <label style={lbl}>SISÄÄNOSTOHINTA (€)</label>
            <input style={inp} type="number" value={form.buyPrice} onChange={e => setForm(f => ({ ...f, buyPrice: e.target.value }))} placeholder="0" />
          </div>
          <div>
            <label style={lbl}>MYYNTIHINTA (€)</label>
            <input style={inp} type="number" value={form.sellPrice || ""} onChange={e => setForm(f => ({ ...f, sellPrice: e.target.value }))} placeholder="0" />
          </div>
          <div style={{ gridColumn: "1/-1" }}>
            <label style={lbl}>KUVAUS / LISÄTIEDOT</label>
            <textarea style={{ ...inp, minHeight: "80px", resize: "vertical" }} value={form.description} onChange={e => setForm(f => ({ ...f, description: e.target.value }))} placeholder="Koko, mitat, huomiot kunnosta..." />
          </div>
          <div style={{ gridColumn: "1/-1" }}>
            <label style={lbl}>KUVAT</label>
            <div style={{ border: `2px dashed ${C.border}`, borderRadius: "10px", padding: "20px", textAlign: "center", cursor: "pointer", background: C.offWhite }} onClick={() => fileRef.current.click()}>
              <div style={{ color: C.textMuted, fontSize: "14px" }}>📷 Klikkaa lisätäksesi kuvia</div>
              <input ref={fileRef} type="file" multiple accept="image/*" style={{ display: "none" }} onChange={handleImageUpload} />
            </div>
            {previewImages.length > 0 && (
              <div style={{ display: "flex", flexWrap: "wrap", gap: "8px", marginTop: "12px" }}>
                {previewImages.map((img, i) => (
                  <div key={i} style={{ position: "relative", width: "80px", height: "80px" }}>
                    <img src={img.src} alt="" style={{ width: "80px", height: "80px", objectFit: "cover", borderRadius: "8px" }} />
                    <button onClick={() => setPreviewImages(p => p.filter((_, j) => j !== i))} style={{ position: "absolute", top: "-6px", right: "-6px", background: C.red, border: "none", color: "#fff", borderRadius: "50%", width: "20px", height: "20px", cursor: "pointer", fontSize: "12px" }}>×</button>
                  </div>
                ))}
              </div>
            )}
          </div>
          {/* Lisätty ja myynyt — vain adminille näkyvissä muokkaus */}
          <div style={{ gridColumn: "1/-1", display: "flex", alignItems: "center", gap: "12px", background: C.offWhite, padding: "14px 16px", borderRadius: "8px" }}>
            <label style={{ display: "flex", alignItems: "center", gap: "10px", cursor: "pointer", color: C.navy, fontSize: "14px", fontWeight: 600 }}>
              <input type="checkbox" checked={form.sold} onChange={e => setForm(f => ({ ...f, sold: e.target.checked, soldBy: e.target.checked ? currentUser.id : null }))} style={{ width: "18px", height: "18px", accentColor: C.navy }} />
              Merkitse myydyksi
            </label>
            {form.sold && <input style={{ ...inp, maxWidth: "180px" }} type="date" value={form.soldAt || ""} onChange={e => setForm(f => ({ ...f, soldAt: e.target.value }))} />}
          </div>
        </div>
        <div style={{ display: "flex", gap: "12px", marginTop: "28px" }}>
          <button onClick={() => {
            if (!form.name.trim()) { alert("Anna laitteen nimi."); return; }
            onSave({ ...form, imageData: previewImages, createdAt: form.createdAt || new Date().toISOString().split("T")[0] });
            onClose();
          }} style={{ flex: 1, background: `linear-gradient(135deg, ${C.navy}, ${C.navyLight})`, color: C.white, border: "none", borderRadius: "10px", padding: "14px", fontWeight: 800, fontSize: "15px", cursor: "pointer", fontFamily: "'Barlow Condensed', sans-serif", letterSpacing: "2px" }}>
            {item ? "TALLENNA MUUTOKSET" : "LISÄÄ VARASTOON"}
          </button>
          <button onClick={onClose} style={{ background: "none", border: `1.5px solid ${C.border}`, color: C.textMuted, borderRadius: "10px", padding: "14px 24px", fontSize: "14px", cursor: "pointer" }}>Peruuta</button>
        </div>
      </div>
    </div>
  );
}

// ── ITEM CARD ─────────────────────────────────────────────────────────────────
function ItemCard({ item, onEdit, onMarkSold, onPriceSearch, currentUser }) {
  const cat = CATEGORIES.find(c => c.id === item.category);
  const cond = CONDITION_LABELS[item.condition];
  const profit = item.sold && item.sellPrice && item.buyPrice ? Number(item.sellPrice) - Number(item.buyPrice) : null;
  const soldByUser = item.soldBy ? USERS.find(u => u.id === item.soldBy) : null;
  const addedByUser = item.addedBy ? USERS.find(u => u.id === item.addedBy) : null;

  return (
    <div style={{ background: C.white, borderRadius: "12px", overflow: "hidden", border: `1px solid ${C.border}`, opacity: item.sold ? 0.82 : 1, boxShadow: item.sold ? "none" : "0 2px 12px rgba(30,58,110,0.08)" }}>
      {item.imageData?.length > 0 ? (
        <div style={{ height: "155px", overflow: "hidden", position: "relative" }}>
          <img src={item.imageData[0].src} alt="" style={{ width: "100%", height: "100%", objectFit: "cover" }} />
          {item.imageData.length > 1 && <div style={{ position: "absolute", bottom: "8px", right: "8px", background: "rgba(30,58,110,0.85)", color: "#fff", fontSize: "11px", padding: "3px 8px", borderRadius: "12px" }}>+{item.imageData.length - 1} kuvaa</div>}
          {item.sold && <div style={{ position: "absolute", inset: 0, background: "rgba(30,58,110,0.4)", display: "flex", alignItems: "center", justifyContent: "center" }}><div style={{ background: C.navy, color: C.white, fontWeight: 800, fontSize: "13px", padding: "6px 20px", borderRadius: "4px", letterSpacing: "3px", fontFamily: "'Barlow Condensed', sans-serif", transform: "rotate(-5deg)" }}>MYYTY</div></div>}
        </div>
      ) : (
        <div style={{ height: "68px", background: `linear-gradient(135deg, ${C.navy}0d, ${C.blue}1a)`, display: "flex", alignItems: "center", justifyContent: "center", fontSize: "26px", position: "relative", borderBottom: `1px solid ${C.borderLight}` }}>
          {cat?.icon}
          {item.sold && <div style={{ position: "absolute", top: "8px", right: "8px", background: C.navy, color: C.white, fontWeight: 800, fontSize: "10px", padding: "3px 10px", borderRadius: "4px", letterSpacing: "2px", fontFamily: "'Barlow Condensed', sans-serif" }}>MYYTY</div>}
        </div>
      )}
      <div style={{ padding: "14px" }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: "4px" }}>
          <div style={{ color: C.navy, fontSize: "15px", fontWeight: 700, lineHeight: 1.3, flex: 1, marginRight: "8px", fontFamily: "'Barlow Condensed', sans-serif" }}>{item.name}</div>
          <div style={{ background: cond?.bg, color: cond?.color, fontSize: "10px", padding: "3px 8px", borderRadius: "20px", whiteSpace: "nowrap", fontWeight: 700 }}>{cond?.label}</div>
        </div>
        <div style={{ color: C.textMuted, fontSize: "12px", marginBottom: "8px" }}>{cat?.icon} {cat?.label}</div>

        {item.description && <div style={{ color: C.textMuted, fontSize: "12px", lineHeight: 1.5, marginBottom: "10px", borderLeft: `3px solid ${C.blue}`, paddingLeft: "10px", background: C.offWhite, padding: "7px 10px", borderRadius: "0 6px 6px 0" }}>{item.description}</div>}

        {/* Hinnat */}
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "8px", marginBottom: "10px" }}>
          <div style={{ background: C.offWhite, borderRadius: "8px", padding: "9px" }}>
            <div style={{ color: C.textLight, fontSize: "10px", letterSpacing: "1px", marginBottom: "2px", fontWeight: 700 }}>SISÄÄNOSTOHINTA</div>
            <div style={{ color: C.navy, fontSize: "15px", fontWeight: 800, fontFamily: "'Barlow Condensed', sans-serif" }}>{formatEur(item.buyPrice)}</div>
          </div>
          <div style={{ background: C.offWhite, borderRadius: "8px", padding: "9px" }}>
            <div style={{ color: C.textLight, fontSize: "10px", letterSpacing: "1px", marginBottom: "2px", fontWeight: 700 }}>MYYNTIHINTA</div>
            <div style={{ color: item.sold ? C.navyLight : C.navy, fontSize: "15px", fontWeight: 800, fontFamily: "'Barlow Condensed', sans-serif" }}>{formatEur(item.sellPrice)}</div>
          </div>
          {profit !== null && (
            <div style={{ gridColumn: "1/-1", background: profit >= 0 ? C.greenBg : C.redBg, borderRadius: "8px", padding: "9px", border: `1px solid ${profit >= 0 ? C.green : C.red}33` }}>
              <div style={{ color: profit >= 0 ? C.green : C.red, fontSize: "10px", letterSpacing: "1px", marginBottom: "2px", fontWeight: 700 }}>TUOTTO</div>
              <div style={{ color: profit >= 0 ? C.green : C.red, fontSize: "17px", fontWeight: 800, fontFamily: "'Barlow Condensed', sans-serif" }}>{profit >= 0 ? "+" : ""}{formatEur(profit)}</div>
            </div>
          )}
        </div>

        {/* Kuka lisäsi / myi */}
        <div style={{ display: "flex", gap: "6px", marginBottom: "10px", flexWrap: "wrap" }}>
          {addedByUser && (
            <div style={{ background: C.offWhite, border: `1px solid ${C.borderLight}`, borderRadius: "20px", padding: "3px 10px", fontSize: "11px", color: C.textMuted }}>
              ➕ {addedByUser.name.split(" ")[0]}
            </div>
          )}
          {soldByUser && (
            <div style={{ background: "#e8f0fe", border: `1px solid ${C.blue}33`, borderRadius: "20px", padding: "3px 10px", fontSize: "11px", color: C.navyLight, fontWeight: 600 }}>
              ✓ Myynyt: {soldByUser.name.split(" ")[0]}
            </div>
          )}
        </div>

        {/* Napit */}
        <div style={{ display: "flex", gap: "6px", flexWrap: "wrap" }}>
          {!item.sold && (
            <>
              <button onClick={() => onMarkSold(item.id)} style={{ flex: 1, background: `linear-gradient(135deg, ${C.navy}, ${C.navyLight})`, color: C.white, border: "none", borderRadius: "8px", padding: "9px 12px", fontSize: "12px", fontWeight: 800, cursor: "pointer", fontFamily: "'Barlow Condensed', sans-serif", letterSpacing: "1px" }}>✓ MERKITSE MYYDYKSI</button>
              <button onClick={() => onPriceSearch(item)} style={{ background: C.offWhite, border: `1px solid ${C.border}`, color: C.navyLight, borderRadius: "8px", padding: "9px 12px", fontSize: "12px", cursor: "pointer", fontWeight: 700 }}>🔍</button>
            </>
          )}
          <button onClick={() => onEdit(item)} style={{ background: C.offWhite, border: `1px solid ${C.border}`, color: C.textMuted, borderRadius: "8px", padding: "9px 12px", fontSize: "12px", cursor: "pointer" }}>✏️</button>
        </div>
      </div>
    </div>
  );
}

// ── LEADERBOARD / MY SALES VIEW ───────────────────────────────────────────────
function SalesView({ items, currentUser, onClose }) {
  const isAdmin = currentUser.role === "admin";

  const stats = USERS.filter(u => u.role === "user").map(u => {
    const sold = items.filter(i => i.sold && i.soldBy === u.id);
    const revenue = sold.reduce((s, i) => s + (Number(i.sellPrice) || 0), 0);
    const profit = sold.reduce((s, i) => s + ((Number(i.sellPrice) || 0) - (Number(i.buyPrice) || 0)), 0);
    return { user: u, count: sold.length, revenue, profit, items: sold };
  }).sort((a, b) => b.revenue - a.revenue);

  const myStats = stats.find(s => s.user.id === currentUser.id);
  const viewStats = isAdmin ? stats : (myStats ? [myStats] : []);

  return (
    <div style={{ position: "fixed", inset: 0, background: "rgba(15,30,60,0.7)", zIndex: 1000, display: "flex", alignItems: "center", justifyContent: "center", padding: "20px" }}>
      <div style={{ background: C.white, borderRadius: "16px", width: "100%", maxWidth: "600px", padding: "20px 16px", maxHeight: "90vh", overflowY: "auto", boxShadow: "0 24px 64px rgba(30,58,110,0.3)" }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "24px" }}>
          <div>
            <div style={{ color: C.blue, fontSize: "11px", letterSpacing: "3px", fontWeight: 700, fontFamily: "'Barlow Condensed', sans-serif", marginBottom: "4px" }}>
              {isAdmin ? "MYYNTITILASTOT" : "OMAT MYYNNIT"}
            </div>
            <div style={{ color: C.navy, fontSize: "22px", fontWeight: 800, fontFamily: "'Barlow Condensed', sans-serif" }}>
              {isAdmin ? "Kaikki myyjät" : currentUser.name}
            </div>
          </div>
          <button onClick={onClose} style={{ background: C.offWhite, border: "none", color: C.textMuted, fontSize: "20px", cursor: "pointer", borderRadius: "8px", width: "36px", height: "36px" }}>×</button>
        </div>

        {isAdmin && (
          <div style={{ marginBottom: "20px" }}>
            <div style={{ color: C.textMuted, fontSize: "11px", letterSpacing: "2px", fontWeight: 700, marginBottom: "10px", fontFamily: "'Barlow Condensed', sans-serif" }}>TULOSTAULUKKO</div>
            {stats.map((s, i) => (
              <div key={s.user.id} style={{ display: "flex", alignItems: "center", gap: "14px", background: i === 0 ? C.goldBg : C.offWhite, border: `1px solid ${i === 0 ? C.gold+"44" : C.borderLight}`, borderRadius: "10px", padding: "14px 16px", marginBottom: "8px" }}>
                <div style={{ fontFamily: "'Barlow Condensed', sans-serif", fontSize: "22px", fontWeight: 800, color: i === 0 ? C.gold : i === 1 ? "#aaa" : i === 2 ? "#cd7f32" : C.textLight, width: "28px", textAlign: "center" }}>
                  {i === 0 ? "🥇" : i === 1 ? "🥈" : i === 2 ? "🥉" : `${i+1}.`}
                </div>
                <div style={{ flex: 1 }}>
                  <div style={{ color: C.navy, fontWeight: 700, fontSize: "15px" }}>{s.user.name}</div>
                  <div style={{ color: C.textMuted, fontSize: "12px", marginTop: "2px" }}>{s.count} myyntiä</div>
                </div>
                <div style={{ textAlign: "right" }}>
                  <div style={{ color: C.navy, fontWeight: 800, fontSize: "16px", fontFamily: "'Barlow Condensed', sans-serif" }}>{formatEur(s.revenue)}</div>
                  <div style={{ color: s.profit >= 0 ? C.green : C.red, fontSize: "12px", fontWeight: 600 }}>+{formatEur(s.profit)} tuotto</div>
                </div>
              </div>
            ))}
          </div>
        )}

        {viewStats.map(s => (
          <div key={s.user.id}>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(120px, 1fr))", gap: "8px", marginBottom: "16px" }}>
              {[
                { label: "MYYNTEJÄ", value: s.count + " kpl", color: C.navy },
                { label: "MYYNTI YHT.", value: formatEur(s.revenue), color: C.navyLight },
                { label: "TUOTTO YHT.", value: formatEur(s.profit), color: s.profit >= 0 ? C.green : C.red },
              ].map((st, i) => (
                <div key={i} style={{ background: C.offWhite, borderRadius: "10px", padding: "14px", border: `1px solid ${C.borderLight}` }}>
                  <div style={{ color: C.textLight, fontSize: "10px", letterSpacing: "1px", fontWeight: 700, marginBottom: "4px" }}>{st.label}</div>
                  <div style={{ color: st.color, fontSize: "18px", fontWeight: 800, fontFamily: "'Barlow Condensed', sans-serif" }}>{st.value}</div>
                </div>
              ))}
            </div>
            {s.items.length > 0 && (
              <div>
                <div style={{ color: C.textMuted, fontSize: "11px", letterSpacing: "2px", fontWeight: 700, marginBottom: "8px", fontFamily: "'Barlow Condensed', sans-serif" }}>MYYDYT LAITTEET</div>
                {s.items.map(it => (
                  <div key={it.id} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", background: C.offWhite, borderRadius: "8px", padding: "10px 14px", marginBottom: "6px", border: `1px solid ${C.borderLight}` }}>
                    <div>
                      <div style={{ color: C.navy, fontSize: "13px", fontWeight: 600 }}>{it.name}</div>
                      <div style={{ color: C.textMuted, fontSize: "11px" }}>{it.soldAt}</div>
                    </div>
                    <div style={{ textAlign: "right" }}>
                      <div style={{ color: C.navy, fontWeight: 700, fontSize: "14px", fontFamily: "'Barlow Condensed', sans-serif" }}>{formatEur(it.sellPrice)}</div>
                      <div style={{ color: C.green, fontSize: "11px", fontWeight: 600 }}>+{formatEur(Number(it.sellPrice) - Number(it.buyPrice))}</div>
                    </div>
                  </div>
                ))}
              </div>
            )}
            {s.items.length === 0 && <div style={{ color: C.textMuted, fontSize: "14px", textAlign: "center", padding: "24px" }}>Ei myyntejä vielä.</div>}
          </div>
        ))}
      </div>
    </div>
  );
}



// ── SELL MODAL ────────────────────────────────────────────────────────────────
function SellModal({ item, onConfirm, onMakeInvoice, onClose }) {
  const cat = CATEGORIES.find(c => c.id === item.category);
  const [price, setPrice] = useState(String(item.sellPrice || ""));
  const [makeInvoice, setMakeInvoice] = useState(true);

  const originalPrice = item.sellPrice;
  const changed = originalPrice && Number(price) !== Number(originalPrice);

  return (
    <div style={{ position: "fixed", inset: 0, background: "rgba(15,30,60,0.7)", zIndex: 1000, display: "flex", alignItems: "center", justifyContent: "center", padding: "20px" }}>
      <div style={{ background: C.white, borderRadius: "16px", width: "100%", maxWidth: "420px", padding: "28px 20px", boxShadow: "0 24px 64px rgba(30,58,110,0.3)" }}>

        {/* Header */}
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: "20px" }}>
          <div>
            <div style={{ color: C.blue, fontSize: "10px", letterSpacing: "3px", fontWeight: 700, fontFamily: "'Barlow Condensed', sans-serif", marginBottom: "4px" }}>MERKITSE MYYDYKSI</div>
            <div style={{ color: C.navy, fontSize: "17px", fontWeight: 800, fontFamily: "'Barlow Condensed', sans-serif", lineHeight: 1.2 }}>{item.name}</div>
            <div style={{ color: C.textMuted, fontSize: "12px", marginTop: "3px" }}>{cat?.icon} {cat?.label}</div>
          </div>
          <button onClick={onClose} style={{ background: C.offWhite, border: "none", color: C.textMuted, fontSize: "18px", cursor: "pointer", borderRadius: "8px", width: "34px", height: "34px", flexShrink: 0 }}>×</button>
        </div>

        {/* Price */}
        <div style={{ marginBottom: "16px" }}>
          <label style={{ color: C.textMuted, fontSize: "10px", letterSpacing: "2px", fontWeight: 700, fontFamily: "'Barlow Condensed', sans-serif", display: "block", marginBottom: "8px" }}>MYYNTIHINTA (€)</label>
          <input
            type="number"
            value={price}
            onChange={e => setPrice(e.target.value)}
            placeholder="Anna myyntihinta"
            style={{ background: C.offWhite, border: `2px solid ${changed ? C.amber : C.border}`, borderRadius: "10px", color: C.navy, padding: "14px 16px", fontSize: "22px", fontWeight: 800, fontFamily: "'Barlow Condensed', sans-serif", width: "100%", outline: "none", boxSizing: "border-box" }}
            autoFocus
          />
          {originalPrice && (
            <div style={{ marginTop: "8px", display: "flex", alignItems: "center", gap: "8px" }}>
              <div style={{ fontSize: "12px", color: C.textMuted }}>Alkuperäinen hinta: <strong>{formatEur(originalPrice)}</strong></div>
              {changed && (
                <div style={{ background: C.amberBg, color: C.amber, fontSize: "11px", fontWeight: 700, padding: "2px 8px", borderRadius: "12px" }}>
                  {Number(price) < Number(originalPrice) ? `−${formatEur(Number(originalPrice) - Number(price))} alennus` : `+${formatEur(Number(price) - Number(originalPrice))}`}
                </div>
              )}
            </div>
          )}
        </div>

        {/* Tuotto preview */}
        {price && item.buyPrice && (
          <div style={{ background: Number(price) >= Number(item.buyPrice) ? C.greenBg : C.redBg, border: `1px solid ${Number(price) >= Number(item.buyPrice) ? C.green : C.red}33`, borderRadius: "10px", padding: "12px 16px", marginBottom: "16px", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
            <span style={{ color: C.textMuted, fontSize: "12px" }}>Tuotto tästä myynnistä</span>
            <span style={{ color: Number(price) >= Number(item.buyPrice) ? C.green : C.red, fontWeight: 800, fontSize: "18px", fontFamily: "'Barlow Condensed', sans-serif" }}>
              {Number(price) >= Number(item.buyPrice) ? "+" : ""}{formatEur(Number(price) - Number(item.buyPrice))}
            </span>
          </div>
        )}

        {/* Lasku toggle */}
        <label style={{ display: "flex", alignItems: "center", gap: "12px", cursor: "pointer", background: makeInvoice ? "#e8f0fe" : C.offWhite, border: `1.5px solid ${makeInvoice ? C.blue : C.border}`, borderRadius: "10px", padding: "14px 16px", marginBottom: "20px" }}>
          <input type="checkbox" checked={makeInvoice} onChange={e => setMakeInvoice(e.target.checked)} style={{ width: "18px", height: "18px", accentColor: C.navy, flexShrink: 0 }} />
          <div>
            <div style={{ color: C.navy, fontWeight: 700, fontSize: "14px" }}>🧾 Tee lasku myynnistä</div>
            <div style={{ color: C.textMuted, fontSize: "12px", marginTop: "2px" }}>Laite lisätään automaattisesti laskulle</div>
          </div>
        </label>

        {/* Actions */}
        <div style={{ display: "flex", flexDirection: "column", gap: "10px" }}>
          <button
            onClick={() => { if (!price) return alert("Anna myyntihinta."); makeInvoice ? onMakeInvoice(item, price) : onConfirm(item.id, price); }}
            disabled={!price}
            style={{ background: `linear-gradient(135deg, ${C.navy}, ${C.navyLight})`, color: C.white, border: "none", borderRadius: "10px", padding: "15px", fontWeight: 800, fontSize: "15px", cursor: price ? "pointer" : "not-allowed", fontFamily: "'Barlow Condensed', sans-serif", letterSpacing: "2px", opacity: price ? 1 : 0.5 }}>
            {makeInvoice ? "✓ MYYDÄÄN JA TEE LASKU" : "✓ MERKITSE MYYDYKSI"}
          </button>
          <button onClick={onClose} style={{ background: "none", border: `1px solid ${C.border}`, color: C.textMuted, borderRadius: "10px", padding: "12px", fontSize: "14px", cursor: "pointer" }}>Peruuta</button>
        </div>
      </div>
    </div>
  );
}

// ── INVOICE MODAL ─────────────────────────────────────────────────────────────
let invoiceCounter = 26173; // jatkaa esimerkkilaskun numerosta

function InvoiceModal({ onClose, prefillItem }) {
  const today = new Date().toISOString().split("T")[0];
  const dueDate = new Date(Date.now() + 14*24*60*60*1000).toISOString().split("T")[0];

  const prefillLine = prefillItem
    ? [{ desc: prefillItem.name + " käytetty", qty: 1, unit: "kpl", unitPrice: String(prefillItem.finalPrice || prefillItem.sellPrice || "") }]
    : [{ desc: "", qty: 1, unit: "kpl", unitPrice: "" }];

  const [form, setForm] = useState({
    invoiceNum: String(invoiceCounter++),
    date: today,
    dueDate: dueDate,
    customerName: "",
    customerAddress: "",
    customerCity: "",
    customerYtunnus: "",
    customerRef: "",
    deliveryMethod: "Rahti",
    paymentTerms: "Ennakkomaksu",
    lines: prefillLine,
    includeFreight: false,
    freightPrice: "",
  });
  const [sent, setSent] = useState(false);
  const [sending, setSending] = useState(false);
  const [showPreview, setShowPreview] = useState(false);

  const ALV = 0.255;

  function setField(k, v) { setForm(f => ({ ...f, [k]: v })); }

  function setLine(i, k, v) {
    setForm(f => {
      const lines = [...f.lines];
      lines[i] = { ...lines[i], [k]: v };
      return { ...f, lines };
    });
  }

  function addLine() { setForm(f => ({ ...f, lines: [...f.lines, { desc: "", qty: 1, unit: "kpl", unitPrice: "" }] })); }
  function removeLine(i) { setForm(f => ({ ...f, lines: f.lines.filter((_, j) => j !== i) })); }

  const allLines = [
    ...form.lines,
    ...(form.includeFreight && form.freightPrice ? [{ desc: `Rahti Oulu – ${form.customerCity || "?"}`, qty: 1, unit: "kpl", unitPrice: form.freightPrice }] : [])
  ];

  const totalNet = allLines.reduce((s, l) => s + (Number(l.qty) || 0) * (Number(l.unitPrice) || 0), 0);
  const totalAlv = totalNet * ALV;
  const totalGross = totalNet + totalAlv;
  const refNum = form.invoiceNum.padStart(6, "0");

  function fmt(n) { return Number(n).toLocaleString("fi-FI", { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + " €"; }
  function fmtDate(d) { if (!d) return ""; const [y,m,dd] = d.split("-"); return `${dd}.${m}.${y}`; }

  function buildEmailBody() {
    const lines = allLines.map(l =>
      `${l.desc} | ${l.qty} ${l.unit} | ${fmt(l.unitPrice)} | ${fmt((Number(l.qty)||0)*(Number(l.unitPrice)||0))} | ${fmt((Number(l.qty)||0)*(Number(l.unitPrice)||0)*ALV)}`
    ).join("\n");
    return `LASKU ${form.invoiceNum} / ${fmtDate(form.date)}

MYYJÄ:
Reta-Myynti Oy
Kajaanintie 143, 90230 Oulu
Y-tunnus: 2820981-8
Puh: 0400 682055
retamyynti@gmail.com

ASIAKAS:
${form.customerName}
${form.customerAddress}
${form.customerCity}
${form.customerYtunnus ? "Y-tunnus: " + form.customerYtunnus : ""}

Toimitustapa: ${form.deliveryMethod}
Maksuehdot: ${form.paymentTerms}
Eräpäivä: ${fmtDate(form.dueDate)}
Huomautusaika: 7 pv
Viivästyskorko: Korkolain mukaan
Asiakkaan viite: ${form.customerRef}

TUOTTEET:
Tuote | Määrä | Yksikköhinta | Veroton | ALV 25,5%
${lines}

Arvonlisäveroton yhteensä: ${fmt(totalNet)}
ALV 25,5 %: ${fmt(totalAlv)}
YHTEENSÄ: ${fmt(totalGross)}

Viitenumero: ${refNum}
IBAN: FI91 2050 1800 0695 13 (Nordea)
IBAN: FI24 5740 9220 0000 66 (Pohjolan Osuuspankki)

Tuotteemme myydään luovutushetken kunnossa. Niillä ei ole takuuta, eikä vaihto- tai palautusoikeutta.`;
  }

  async function sendEmail() {
    setSending(true);
    // Save to Supabase
    try {
      await db.saveInvoice({
        invoice_num: form.invoiceNum,
        date: form.date,
        due_date: form.dueDate,
        customer_name: form.customerName,
        customer_address: form.customerAddress,
        customer_city: form.customerCity,
        customer_ytunnus: form.customerYtunnus,
        customer_ref: form.customerRef,
        delivery_method: form.deliveryMethod,
        payment_terms: form.paymentTerms,
        lines: allLines,
        include_freight: form.includeFreight,
        freight_price: form.freightPrice ? Number(form.freightPrice) : null,
        total_net: totalNet,
        total_gross: totalGross,
      });
    } catch(e) { console.error("Invoice save error:", e); }
    const subject = encodeURIComponent(`Lasku ${form.invoiceNum} – ${form.customerName}`);
    const body = encodeURIComponent(buildEmailBody());
    window.open(`mailto:retamyynti@gmail.com?subject=${subject}&body=${body}`);
    setTimeout(() => { setSending(false); setSent(true); }, 800);
  }

  const inp = { background: C.offWhite, border: `1.5px solid ${C.border}`, borderRadius: "7px", color: C.navy, padding: "9px 12px", fontSize: "13px", width: "100%", boxSizing: "border-box", fontFamily: "'Barlow', sans-serif", outline: "none" };
  const lbl = { color: C.textMuted, fontSize: "10px", letterSpacing: "2px", marginBottom: "5px", display: "block", fontWeight: 700, fontFamily: "'Barlow Condensed', sans-serif" };
  const section = { marginBottom: "20px" };
  const sectionTitle = { color: C.navy, fontSize: "13px", letterSpacing: "2px", fontWeight: 800, fontFamily: "'Barlow Condensed', sans-serif", marginBottom: "12px", paddingBottom: "6px", borderBottom: `2px solid ${C.border}` };

  if (showPreview) {
    // Print-friendly preview
    return (
      <div style={{ position: "fixed", inset: 0, background: "rgba(15,30,60,0.7)", zIndex: 1000, display: "flex", alignItems: "flex-start", justifyContent: "center", padding: "20px", overflowY: "auto" }}>
        <div style={{ background: C.white, width: "100%", maxWidth: "720px", padding: "20px 16px", borderRadius: "12px", boxShadow: "0 24px 64px rgba(30,58,110,0.3)", fontFamily: "'Barlow', sans-serif" }}>
          {/* Invoice header */}
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: "28px" }}>
            <div>
              <div style={{ fontWeight: 800, fontSize: "18px", color: C.navy, marginBottom: "4px" }}>Reta-Myynti Oy</div>
              <div style={{ fontSize: "13px", color: C.textMuted, lineHeight: 1.7 }}>
                Kajaanintie 143<br />FIN-90230 Oulu<br /><br />
                Yhteyshenkilö: Matti Pohjola 0400-682055
              </div>
            </div>
            <div style={{ textAlign: "right" }}>
              <div style={{ fontFamily: "'Barlow Condensed', sans-serif", fontWeight: 800, fontSize: "22px", display: "flex", alignItems: "center", gap: "6px", justifyContent: "flex-end", marginBottom: "8px" }}>
                RETA <svg width="11" height="13" viewBox="0 0 12 14"><polygon points="0,0 12,7 0,14" fill={C.blue} /></svg> MYYNTI
              </div>
              <div style={{ fontSize: "28px", fontWeight: 800, color: C.navy, fontFamily: "'Barlow Condensed', sans-serif", letterSpacing: "2px" }}>LASKU</div>
              <div style={{ fontSize: "13px", color: C.textMuted, marginTop: "8px", lineHeight: 1.8 }}>
                <span style={{ color: C.navy, fontWeight: 600 }}>Laskun numero</span> {form.invoiceNum}<br />
                <span style={{ color: C.navy, fontWeight: 600 }}>Laskun päivämäärä</span> {fmtDate(form.date)}
              </div>
            </div>
          </div>

          {/* Customer + terms */}
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(220px, 1fr))", gap: "16px", marginBottom: "20px" }}>
            <div>
              <div style={{ fontSize: "11px", fontWeight: 700, color: C.textMuted, letterSpacing: "2px", marginBottom: "8px" }}>ASIAKAS / MAKSAJA</div>
              <div style={{ fontSize: "14px", color: C.navy, lineHeight: 1.8 }}>
                <strong>{form.customerName}</strong><br />
                {form.customerAddress}<br />
                {form.customerCity}
              </div>
            </div>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "8px", fontSize: "12px" }}>
              {[
                ["Asiakkaan Y-tunnus", form.customerYtunnus || "—"],
                ["Maksuehdot", form.paymentTerms],
                ["Toimitustapa", form.deliveryMethod],
                ["Eräpäivä", fmtDate(form.dueDate)],
                ["Viivästyskorko", "Korkolain mukaan"],
                ["Huomautusaika", "7 pv"],
                ["Asiakkaan viite", form.customerRef || "—"],
              ].map(([k,v],i) => (
                <div key={i}>
                  <div style={{ color: C.textMuted, fontSize: "10px", fontWeight: 700 }}>{k}</div>
                  <div style={{ color: C.navy, fontWeight: 600 }}>{v}</div>
                </div>
              ))}
            </div>
          </div>

          {/* Lines table */}
          <table style={{ width: "100%", borderCollapse: "collapse", marginBottom: "20px", fontSize: "13px" }}>
            <thead>
              <tr style={{ borderBottom: `2px solid ${C.navy}` }}>
                {["Tuotenimike","Määrä","Yksikkö","Yksikköhinta","Yhteensä ALV 0%","ALV %","Yhteensä ALV 25,5%"].map(h => (
                  <th key={h} style={{ textAlign: h === "Tuotenimike" ? "left" : "right", padding: "6px 8px", color: C.navy, fontWeight: 700, fontSize: "11px" }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {allLines.map((l, i) => {
                const net = (Number(l.qty)||0) * (Number(l.unitPrice)||0);
                return (
                  <tr key={i} style={{ borderBottom: `1px solid ${C.borderLight}` }}>
                    <td style={{ padding: "8px", color: C.navy }}>{l.desc}</td>
                    <td style={{ padding: "8px", textAlign: "right" }}>{l.qty}</td>
                    <td style={{ padding: "8px", textAlign: "right" }}>{l.unit}</td>
                    <td style={{ padding: "8px", textAlign: "right" }}>{fmt(l.unitPrice)}</td>
                    <td style={{ padding: "8px", textAlign: "right" }}>{fmt(net)}</td>
                    <td style={{ padding: "8px", textAlign: "right" }}>25,5 %</td>
                    <td style={{ padding: "8px", textAlign: "right", fontWeight: 600 }}>{fmt(net * (1+ALV))}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>

          {/* Totals */}
          <div style={{ display: "flex", justifyContent: "flex-end", marginBottom: "24px" }}>
            <div style={{ width: "260px" }}>
              <div style={{ display: "flex", justifyContent: "space-between", padding: "5px 0", fontSize: "13px" }}>
                <span style={{ color: C.textMuted }}>Arvonlisäveroton yhteensä</span>
                <span style={{ fontWeight: 600 }}>{fmt(totalNet)}</span>
              </div>
              <div style={{ display: "flex", justifyContent: "space-between", padding: "5px 0", fontSize: "13px" }}>
                <span style={{ color: C.textMuted }}>Arvonlisävero yhteensä</span>
                <span style={{ fontWeight: 600 }}>{fmt(totalAlv)}</span>
              </div>
              <div style={{ display: "flex", justifyContent: "space-between", padding: "8px 0", fontSize: "16px", borderTop: `2px solid ${C.navy}`, marginTop: "4px" }}>
                <span style={{ fontWeight: 800, color: C.navy }}>Lasku yhteensä euroa</span>
                <span style={{ fontWeight: 800, color: C.navy }}>{fmt(totalGross)}</span>
              </div>
            </div>
          </div>

          {/* Disclaimer */}
          <div style={{ fontSize: "11px", color: C.textMuted, lineHeight: 1.6, marginBottom: "20px", borderTop: `1px solid ${C.border}`, paddingTop: "12px" }}>
            Tuotteemme myydään luovutushetken kunnossa ja varustein. Niillä ei ole takuuta, eikä vaihto- tai palautusoikeutta. Reta-Myynti Oy pidättää omistusoikeuden myymiinsä tuotteisiin, kunnes ne ovat kokonaisuudessaan korkoineen ja kuluineen maksettu.
          </div>

          {/* Bank details */}
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "10px", fontSize: "11px", color: C.textMuted, borderTop: `1px solid ${C.border}`, paddingTop: "12px", marginBottom: "20px" }}>
            <div><strong style={{ color: C.navy }}>Reta-Myynti Oy</strong><br />Kotipaikka Oulu<br />ALV rek.<br />Y-tunnus 2820981-8</div>
            <div><strong style={{ color: C.navy }}>Osoite</strong><br />Kajaanintie 143<br />90230 Oulu<br />Finland</div>
            <div><strong style={{ color: C.navy }}>Puhelin</strong><br />0400 682055<br /><strong style={{ color: C.navy }}>Sähköposti</strong><br />retamyynti@gmail.com</div>
            <div><strong style={{ color: C.navy }}>Pankkiyhteydet</strong><br />Nordea: FI91 2050 1800 0695 13<br />BIC: NDEAFIHH<br />Pohjolan Op: FI24 5740 9220 0000 66</div>
          </div>

          {/* Viitenumero box */}
          <div style={{ border: `2px solid ${C.navy}`, borderRadius: "8px", padding: "12px 16px", display: "flex", justifyContent: "space-between", alignItems: "center", background: C.offWhite }}>
            <div>
              <div style={{ fontSize: "10px", color: C.textMuted, fontWeight: 700 }}>VIITENUMERO</div>
              <div style={{ fontSize: "18px", fontWeight: 800, color: C.navy, fontFamily: "'Barlow Condensed', sans-serif", letterSpacing: "2px" }}>{refNum}</div>
            </div>
            <div style={{ textAlign: "right" }}>
              <div style={{ fontSize: "10px", color: C.textMuted, fontWeight: 700 }}>LASKU YHTEENSÄ EUROA</div>
              <div style={{ fontSize: "22px", fontWeight: 800, color: C.navy, fontFamily: "'Barlow Condensed', sans-serif" }}>{fmt(totalGross)}</div>
            </div>
          </div>

          {/* Actions */}
          <div style={{ display: "flex", gap: "10px", marginTop: "24px" }}>
            {sent ? (
              <div style={{ flex: 1, background: C.greenBg, border: `1px solid ${C.green}`, borderRadius: "10px", padding: "14px", textAlign: "center", color: C.green, fontWeight: 700 }}>
                ✓ Sähköposti avattu — lähetä kirjanpitoon
              </div>
            ) : (
              <button onClick={sendEmail} disabled={sending} style={{ flex: 1, background: `linear-gradient(135deg, ${C.navy}, ${C.navyLight})`, color: C.white, border: "none", borderRadius: "10px", padding: "14px", fontWeight: 800, fontSize: "14px", cursor: "pointer", fontFamily: "'Barlow Condensed', sans-serif", letterSpacing: "2px" }}>
                {sending ? "Avataan..." : "📧 LÄHETÄ SÄHKÖPOSTILLA"}
              </button>
            )}
            <button onClick={() => setShowPreview(false)} style={{ background: C.offWhite, border: `1px solid ${C.border}`, color: C.textMuted, borderRadius: "10px", padding: "14px 20px", fontSize: "13px", cursor: "pointer" }}>← Muokkaa</button>
            <button onClick={onClose} style={{ background: "none", border: `1px solid ${C.border}`, color: C.textMuted, borderRadius: "10px", padding: "14px 20px", fontSize: "13px", cursor: "pointer" }}>Sulje</button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div style={{ position: "fixed", inset: 0, background: "rgba(15,30,60,0.7)", zIndex: 1000, display: "flex", alignItems: "center", justifyContent: "center", padding: "20px", overflowY: "auto" }}>
      <div style={{ background: C.white, borderRadius: "16px", width: "100%", maxWidth: "680px", padding: "20px 16px", maxHeight: "94vh", overflowY: "auto", boxShadow: "0 24px 64px rgba(30,58,110,0.3)" }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "24px" }}>
          <div style={{ fontFamily: "'Barlow Condensed', sans-serif", color: C.navy, fontSize: "22px", fontWeight: 800 }}>TEE LASKU</div>
          <button onClick={onClose} style={{ background: C.offWhite, border: "none", color: C.textMuted, fontSize: "20px", cursor: "pointer", borderRadius: "8px", width: "36px", height: "36px" }}>×</button>
        </div>

        {/* Laskun tiedot */}
        <div style={section}>
          <div style={sectionTitle}>LASKUN TIEDOT</div>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(140px, 1fr))", gap: "10px" }}>
            <div><label style={lbl}>LASKUNUMERO</label><input style={inp} value={form.invoiceNum} onChange={e => setField("invoiceNum", e.target.value)} /></div>
            <div><label style={lbl}>PÄIVÄMÄÄRÄ</label><input style={inp} type="date" value={form.date} onChange={e => setField("date", e.target.value)} /></div>
            <div><label style={lbl}>ERÄPÄIVÄ</label><input style={inp} type="date" value={form.dueDate} onChange={e => setField("dueDate", e.target.value)} /></div>
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "12px", marginTop: "10px" }}>
            <div><label style={lbl}>TOIMITUSTAPA</label>
              <select style={inp} value={form.deliveryMethod} onChange={e => setField("deliveryMethod", e.target.value)}>
                {["Rahti","Nouto","Toimitus","Kuljetus"].map(v => <option key={v}>{v}</option>)}
              </select>
            </div>
            <div><label style={lbl}>MAKSUEHDOT</label>
              <select style={inp} value={form.paymentTerms} onChange={e => setField("paymentTerms", e.target.value)}>
                {["Ennakkomaksu","14 pv netto","30 pv netto","Käteinen"].map(v => <option key={v}>{v}</option>)}
              </select>
            </div>
          </div>
        </div>

        {/* Asiakas */}
        <div style={section}>
          <div style={sectionTitle}>ASIAKAS</div>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "12px" }}>
            <div style={{ gridColumn: "1/-1" }}><label style={lbl}>NIMI / YRITYS *</label><input style={inp} value={form.customerName} onChange={e => setField("customerName", e.target.value)} placeholder="Mikko Uotila Tmi" /></div>
            <div><label style={lbl}>KATUOSOITE</label><input style={inp} value={form.customerAddress} onChange={e => setField("customerAddress", e.target.value)} placeholder="Supantie 162" /></div>
            <div><label style={lbl}>POSTINUMERO JA KAUPUNKI</label><input style={inp} value={form.customerCity} onChange={e => setField("customerCity", e.target.value)} placeholder="46810 Ummeljoki" /></div>
            <div><label style={lbl}>Y-TUNNUS</label><input style={inp} value={form.customerYtunnus} onChange={e => setField("customerYtunnus", e.target.value)} placeholder="1857863-6" /></div>
            <div><label style={lbl}>ASIAKKAAN VIITE</label><input style={inp} value={form.customerRef} onChange={e => setField("customerRef", e.target.value)} placeholder="esim. Mikko" /></div>
          </div>
        </div>

        {/* Tuoterivit */}
        <div style={section}>
          <div style={sectionTitle}>TUOTTEET</div>
          {form.lines.map((line, i) => (
            <div key={i} style={{ display: "grid", gridTemplateColumns: "1fr", gap: "8px", marginBottom: "14px", padding: "12px", background: C.offWhite, borderRadius: "8px", border: `1px solid ${C.border}` }}>
              <div><label style={{ ...lbl, opacity: i > 0 ? 0 : 1 }}>TUOTE / KUVAUS</label><input style={inp} value={line.desc} onChange={e => setLine(i, "desc", e.target.value)} placeholder="esim. Electrolux kupupesukone käytetty" /></div>
              <div><label style={{ ...lbl, opacity: i > 0 ? 0 : 1 }}>MÄÄRÄ</label><input style={inp} type="number" value={line.qty} onChange={e => setLine(i, "qty", e.target.value)} /></div>
              <div><label style={{ ...lbl, opacity: i > 0 ? 0 : 1 }}>YKS.</label>
                <select style={inp} value={line.unit} onChange={e => setLine(i, "unit", e.target.value)}>
                  {["kpl","h","pv","erä"].map(v => <option key={v}>{v}</option>)}
                </select>
              </div>
              <div><label style={{ ...lbl, opacity: i > 0 ? 0 : 1 }}>YKSIKKÖHINTA (€)</label><input style={inp} type="number" value={line.unitPrice} onChange={e => setLine(i, "unitPrice", e.target.value)} placeholder="0.00" /></div>
              <button onClick={() => removeLine(i)} style={{ background: C.redBg, border: "none", color: C.red, borderRadius: "6px", width: "32px", height: "36px", cursor: "pointer", fontSize: "16px", marginTop: i === 0 ? "18px" : "0" }}>×</button>
            </div>
          ))}
          <button onClick={addLine} style={{ background: "none", border: `1.5px dashed ${C.border}`, color: C.textMuted, borderRadius: "8px", padding: "9px", fontSize: "13px", cursor: "pointer", width: "100%", marginTop: "4px" }}>+ Lisää rivi</button>

          {/* Rahti */}
          <div style={{ display: "flex", alignItems: "center", gap: "12px", marginTop: "12px", background: C.offWhite, padding: "12px", borderRadius: "8px" }}>
            <label style={{ display: "flex", alignItems: "center", gap: "8px", cursor: "pointer", fontSize: "13px", color: C.navy, fontWeight: 600 }}>
              <input type="checkbox" checked={form.includeFreight} onChange={e => setField("includeFreight", e.target.checked)} style={{ accentColor: C.navy, width: "16px", height: "16px" }} />
              Lisää rahti
            </label>
            {form.includeFreight && <input style={{ ...inp, maxWidth: "160px" }} type="number" value={form.freightPrice} onChange={e => setField("freightPrice", e.target.value)} placeholder="Rahtihinta €" />}
          </div>
        </div>

        {/* Yhteenveto */}
        <div style={{ background: C.navy, borderRadius: "10px", padding: "16px 20px", marginBottom: "20px" }}>
          <div style={{ display: "flex", justifyContent: "space-between", color: "#a8c4e8", fontSize: "13px", marginBottom: "6px" }}>
            <span>Veroton yhteensä</span><span>{fmt(totalNet)}</span>
          </div>
          <div style={{ display: "flex", justifyContent: "space-between", color: "#a8c4e8", fontSize: "13px", marginBottom: "10px" }}>
            <span>ALV 25,5 %</span><span>{fmt(totalAlv)}</span>
          </div>
          <div style={{ display: "flex", justifyContent: "space-between", color: C.white, fontSize: "20px", fontWeight: 800, fontFamily: "'Barlow Condensed', sans-serif", borderTop: "1px solid rgba(255,255,255,0.2)", paddingTop: "10px" }}>
            <span>YHTEENSÄ</span><span>{fmt(totalGross)}</span>
          </div>
        </div>

        <div style={{ display: "flex", gap: "10px" }}>
          <button onClick={() => { if (!form.customerName) { alert("Anna asiakkaan nimi."); return; } setShowPreview(true); }} style={{ flex: 1, background: `linear-gradient(135deg, ${C.navy}, ${C.navyLight})`, color: C.white, border: "none", borderRadius: "10px", padding: "14px", fontWeight: 800, fontSize: "14px", cursor: "pointer", fontFamily: "'Barlow Condensed', sans-serif", letterSpacing: "2px" }}>
            ESIKATSELE LASKU →
          </button>
          <button onClick={onClose} style={{ background: "none", border: `1.5px solid ${C.border}`, color: C.textMuted, borderRadius: "10px", padding: "14px 20px", fontSize: "13px", cursor: "pointer" }}>Peruuta</button>
        </div>
      </div>
    </div>
  );
}

// ── MAIN APP ──────────────────────────────────────────────────────────────────
export default function App() {
  const [currentUser, setCurrentUser] = useState(null);
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [editItem, setEditItem] = useState(null);
  const [searchItem, setSearchItem] = useState(null);
  const [showSales, setShowSales] = useState(false);
  const [showInvoice, setShowInvoice] = useState(false);
  const [sellItem, setSellItem] = useState(null);
  const [invoiceItem, setInvoiceItem] = useState(null);
  const [filter, setFilter] = useState("all");
  const [catFilter, setCatFilter] = useState("all");
  const [search, setSearch] = useState("");

  // Lataa laitteet Supabasesta kun kirjaudutaan
  useEffect(() => {
    if (!currentUser) return;
    setLoading(true);
    db.getItems().then(rows => {
      if (Array.isArray(rows)) setItems(rows.map(fromDb));
      setLoading(false);
    }).catch(() => setLoading(false));
  }, [currentUser]);

  if (!currentUser) return <LoginScreen onLogin={setCurrentUser} />;

  async function handleSave(data) {
    if (data.id) {
      await db.updateItem(data.id, data);
      setItems(prev => prev.map(it => it.id === data.id ? data : it));
    } else {
      const rows = await db.addItem({ ...data, addedBy: currentUser.id });
      if (rows && rows[0]) setItems(prev => [fromDb(rows[0]), ...prev]);
    }
  }

  function handleMarkSold(id) {
    const item = items.find(it => it.id === id);
    setSellItem(item);
  }

  async function confirmSold(id, price) {
    const updated = { ...items.find(it => it.id === id), sold: true, sellPrice: Number(price), soldAt: new Date().toISOString().split("T")[0], soldBy: currentUser.id };
    await db.updateItem(id, updated);
    setItems(prev => prev.map(it => it.id === id ? updated : it));
    setSellItem(null);
  }

  const filtered = items.filter(it => {
    if (filter === "stock" && it.sold) return false;
    if (filter === "sold" && !it.sold) return false;
    if (catFilter !== "all" && it.category !== catFilter) return false;
    if (search && !it.name.toLowerCase().includes(search.toLowerCase())) return false;
    return true;
  });

  const inStock = items.filter(i => !i.sold).length;
  const soldItems = items.filter(i => i.sold);
  const totalRevenue = soldItems.reduce((s, i) => s + (Number(i.sellPrice) || 0), 0);
  const totalProfit = soldItems.reduce((s, i) => s + ((Number(i.sellPrice) || 0) - (Number(i.buyPrice) || 0)), 0);
  const mySold = soldItems.filter(i => i.soldBy === currentUser.id).length;

  return (
    <div style={{ minHeight: "100vh", background: C.bg, color: C.navy, fontFamily: "'Barlow', sans-serif", overflowX: "hidden", maxWidth: "100vw" }}>
      <link href="https://fonts.googleapis.com/css2?family=Barlow+Condensed:wght@400;600;700;800&family=Barlow:wght@300;400;500;600&display=swap" rel="stylesheet" />
      <style>{`
        *, *::before, *::after { box-sizing: border-box; }
        html, body { overflow-x: hidden; max-width: 100vw; overscroll-behavior-x: none; touch-action: pan-y; }
        input, select, textarea { font-size: 16px !important; }
        @keyframes spin { to { transform: rotate(360deg); } }
      `}</style>

      {/* Loading overlay */}
      {loading && (
        <div style={{ position: "fixed", inset: 0, background: "rgba(255,255,255,0.9)", zIndex: 2000, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: "16px" }}>
          <div style={{ width: "40px", height: "40px", border: `4px solid ${C.border}`, borderTopColor: C.navy, borderRadius: "50%", animation: "spin 0.8s linear infinite" }} />
          <div style={{ color: C.navy, fontFamily: "'Barlow Condensed', sans-serif", fontSize: "16px", fontWeight: 700, letterSpacing: "2px" }}>LADATAAN...</div>
        </div>
      )}

      {/* Header */}
      <div style={{ background: C.white, borderBottom: `2px solid ${C.border}`, padding: "0 14px", boxShadow: "0 2px 12px rgba(30,58,110,0.08)" }}>
        <div style={{ maxWidth: "1400px", margin: "0 auto", display: "flex", alignItems: "center", justifyContent: "space-between", padding: "12px 0", flexWrap: "wrap", gap: "8px" }}>
          <div style={{ display: "flex", alignItems: "center", gap: "16px" }}>
            <RetaLogo />
            <div style={{ width: "1px", height: "32px", background: C.border }} />
            <div style={{ color: C.textMuted, fontSize: "11px", letterSpacing: "2px", fontFamily: "'Barlow Condensed', sans-serif", fontWeight: 600 }}>KÄYTETYT SUURKEITTIÖLAITTEET</div>
          </div>
          <div style={{ display: "flex", alignItems: "center", gap: "10px" }}>
            {/* Current user badge */}
            <button onClick={() => setShowSales(true)} style={{ display: "flex", alignItems: "center", gap: "8px", background: C.offWhite, border: `1px solid ${C.border}`, borderRadius: "10px", padding: "8px 14px", cursor: "pointer", color: C.navy }}>
              <span style={{ fontSize: "16px" }}>{currentUser.avatar}</span>
              <div style={{ textAlign: "left" }}>
                <div style={{ fontSize: "12px", fontWeight: 700 }}>{currentUser.name.split(" ")[0]}</div>
                <div style={{ fontSize: "10px", color: C.textMuted }}>{mySold} myyntiä</div>
              </div>
              <span style={{ color: C.textMuted, fontSize: "12px" }}>📊</span>
            </button>
            <button onClick={() => setCurrentUser(null)} style={{ background: "none", border: `1px solid ${C.border}`, color: C.textMuted, borderRadius: "8px", padding: "8px 12px", fontSize: "12px", cursor: "pointer" }}>Kirjaudu ulos</button>
            <button onClick={() => setShowInvoice(true)} style={{ background: "none", border: `1.5px solid ${C.border}`, color: C.navy, borderRadius: "10px", padding: "10px 18px", fontWeight: 700, fontSize: "13px", cursor: "pointer", fontFamily: "'Barlow Condensed', sans-serif", letterSpacing: "1px" }}>
              🧾 TEE LASKU
            </button>
            <button onClick={() => { setEditItem(null); setShowModal(true); }} style={{ background: `linear-gradient(135deg, ${C.navy}, ${C.navyLight})`, color: C.white, border: "none", borderRadius: "10px", padding: "10px 20px", fontWeight: 800, fontSize: "13px", cursor: "pointer", fontFamily: "'Barlow Condensed', sans-serif", letterSpacing: "2px" }}>
              + LISÄÄ LAITE
            </button>
          </div>
        </div>
      </div>

      <div style={{ maxWidth: "1400px", margin: "0 auto", padding: "12px 14px 24px" }}>
        {/* Stats — admin näkee kaikki, muut vain omat */}
        <div style={{ display: "grid", gridTemplateColumns: "repeat(2, 1fr)", gap: "10px", marginBottom: "20px" }}>
          {[
            { label: "VARASTOSSA", value: inStock, unit: "kpl", color: C.navy, bg: C.white },
            { label: "MYYTY YHT.", value: soldItems.length, unit: "kpl", color: C.textMuted, bg: C.white },
            { label: currentUser.role === "admin" ? "MYYNTI YHT." : "OMAT MYYNNIT", value: currentUser.role === "admin" ? formatEur(totalRevenue) : mySold + " kpl", color: C.navyLight, bg: C.white },
            { label: "TUOTTO YHT.", value: formatEur(totalProfit), color: totalProfit >= 0 ? C.green : C.red, bg: totalProfit >= 0 ? C.greenBg : C.redBg },
          ].map((s, i) => (
            <div key={i} style={{ background: s.bg, border: `1px solid ${C.border}`, borderRadius: "12px", padding: "18px", boxShadow: "0 2px 8px rgba(30,58,110,0.06)" }}>
              <div style={{ color: C.textLight, fontSize: "10px", letterSpacing: "2px", marginBottom: "6px", fontWeight: 700, fontFamily: "'Barlow Condensed', sans-serif" }}>{s.label}</div>
              <div style={{ color: s.color, fontSize: "24px", fontWeight: 800, fontFamily: "'Barlow Condensed', sans-serif" }}>
                {s.value}{s.unit && <span style={{ fontSize: "13px", marginLeft: "4px", fontWeight: 600 }}>{s.unit}</span>}
              </div>
            </div>
          ))}
        </div>

        {/* Filters */}
        <div style={{ display: "flex", gap: "8px", marginBottom: "16px", flexWrap: "wrap", alignItems: "center", background: C.white, padding: "10px 12px", borderRadius: "12px", border: `1px solid ${C.border}` }}>
          <input value={search} onChange={e => setSearch(e.target.value)} placeholder="🔍 Hae nimellä..."
            style={{ background: C.offWhite, border: `1.5px solid ${C.border}`, borderRadius: "8px", padding: "8px 12px", color: C.navy, fontSize: "14px", outline: "none", width: "180px" }} />
          {["all", "stock", "sold"].map(f => (
            <button key={f} onClick={() => setFilter(f)} style={{ background: filter === f ? C.navy : "transparent", color: filter === f ? C.white : C.textMuted, border: `1.5px solid ${filter === f ? C.navy : C.border}`, borderRadius: "8px", padding: "8px 14px", fontSize: "12px", cursor: "pointer", fontWeight: filter === f ? 700 : 500, fontFamily: "'Barlow Condensed', sans-serif", letterSpacing: "1px" }}>
              {f === "all" ? "KAIKKI" : f === "stock" ? "VARASTOSSA" : "MYYTY"}
            </button>
          ))}
          <select value={catFilter} onChange={e => setCatFilter(e.target.value)} style={{ background: C.offWhite, border: `1.5px solid ${C.border}`, borderRadius: "8px", padding: "8px 12px", color: C.navy, fontSize: "12px", outline: "none", cursor: "pointer" }}>
            <option value="all">Kaikki kategoriat</option>
            {CATEGORIES.map(c => <option key={c.id} value={c.id}>{c.icon} {c.label}</option>)}
          </select>
          <div style={{ marginLeft: "auto", color: C.textMuted, fontSize: "13px" }}>{filtered.length} laitetta</div>
        </div>

        {/* Grid */}
        {filtered.length === 0 ? (
          <div style={{ textAlign: "center", padding: "80px 0", color: C.textMuted }}>
            <div style={{ fontSize: "48px", marginBottom: "16px" }}>📦</div>
            <div style={{ fontFamily: "'Barlow Condensed', sans-serif", fontSize: "22px", fontWeight: 700, color: C.navy, marginBottom: "8px" }}>EI TULOKSIA</div>
            <div style={{ fontSize: "14px" }}>Muuta hakuehtoja tai lisää uusi laite</div>
          </div>
        ) : (
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(290px, 1fr))", gap: "16px" }}>
            {filtered.map(item => (
              <ItemCard key={item.id} item={item} currentUser={currentUser}
                onEdit={i => { setEditItem(i); setShowModal(true); }}
                onMarkSold={handleMarkSold}
                onPriceSearch={setSearchItem}
              />
            ))}
          </div>
        )}
      </div>

      {showModal && <ItemModal item={editItem} currentUser={currentUser} onClose={() => { setShowModal(false); setEditItem(null); }} onSave={handleSave} />}
      {searchItem && <PriceSearchModal item={searchItem} onClose={() => setSearchItem(null)} />}
      {showSales && <SalesView items={items} currentUser={currentUser} onClose={() => setShowSales(false)} />}
      {(showInvoice || invoiceItem) && <InvoiceModal prefillItem={invoiceItem} onClose={() => { setShowInvoice(false); setInvoiceItem(null); }} />}
      {sellItem && <SellModal item={sellItem} onConfirm={confirmSold} onMakeInvoice={(item, price) => { confirmSold(item.id, price); setInvoiceItem({ ...item, finalPrice: price }); }} onClose={() => setSellItem(null)} />}
    </div>
  );
}
